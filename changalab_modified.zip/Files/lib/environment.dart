class Environment {
/* ATTENTION Please update your desired data. */

  static const String appName = 'ChangaLab';
  static const String version = '1.0.0';

  static String defaultLangCode = "en";
  static String defaultLanguageName = "English";

  static String defaultPhoneCode = "1"; //don't put + here
  static String defaultCountryCode = "US";
  static int otpTime = 60;
}
