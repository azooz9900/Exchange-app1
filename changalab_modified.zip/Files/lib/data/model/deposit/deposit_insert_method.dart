class DepositInsertModel{
  final String methodCode;
  final double amount;
  final String currency;

  DepositInsertModel({ required this.methodCode, required this.amount, required this.currency});
}