
const Map<String, String> ar = {
  'hello': 'مرحبا',
  'welcome': 'أهلاً وسهلاً',
  'login': 'تسجيل الدخول',
  'logout': 'تسجيل الخروج',
  'email': 'البريد الإلكتروني',
  'password': 'كلمة المرور',
  'forgot_password': 'نسيت كلمة المرور؟',
  'exchange': 'صرف العملة',
  'profile': 'الملف الشخصي',
  'settings': 'الإعدادات',
  'language': 'اللغة',
  'submit': 'إرسال',
  'cancel': 'إلغاء',
};
