import 'linkedin_core.dart';

LinkedinCore getCoreConfig() => LinkedinCore.fromConfig();
