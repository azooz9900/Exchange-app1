// import 'package:changa_lab/core/utils/my_color.dart';
// import 'package:changa_lab/core/utils/my_images.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:swipeable_button_view/swipeable_button_view.dart';

// class SwipeButton extends StatelessWidget {
//   const SwipeButton({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return SwipeableButtonView(
//       buttonText: 'Swipe To Exchange',
//       onFinish: () {},
//       onWaitingProcess: () {},
//       activeColor: MyColor.primary,
//       buttonColor: const Color(0x1AFFFFFF).withOpacity(0.4),
//       buttonWidget: SizedBox(
//         height: 58,
//         width: 56,
//         child: Center(
//             child: SvgPicture.asset(
//           MyImages.rightArrow,
//           width: 20,
//           height: 20,
//         )),
//       ),
//     );
//   }
// }
